import React, { useState, useEffect } from "react";
import axios from "axios";

const API_URL = "https://anapioficeandfire.com/api/houses/";

const App = () => {
  const [houses, setHouses] = useState([]);
  const [selectedHouse, setSelectedHouse] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    axios
      .get(API_URL)
      .then((response) => {
        setHouses(response.data);
        setIsLoading(false);
      })
      .catch((error) => console.log(error));
  }, []);

  const handleSelectHouse = (house) => {
    setSelectedHouse(house);
    setIsEditing(false);
  };

  const handleEditHouse = () => {
    setIsEditing(true);
  };

  const handleUpdateHouse = (updatedHouse) => {
    setIsLoading(true);
    axios
      .put(`${API_URL}${updatedHouse.url.split("/").pop()}`, updatedHouse)
      .then((response) => {
        const updatedHouses = houses.map((house) => {
          if (house.url === updatedHouse.url) {
            return response.data;
          }
          return house;
        });
        setHouses(updatedHouses);
        setSelectedHouse(response.data);
        setIsLoading(false);
        setIsEditing(false);
      })
      .catch((error) => console.log(error));
  };

  const handleDeleteHouse = (house) => {
    setIsLoading(true);
    axios
      .delete(`${API_URL}${house.url.split("/").pop()}`)
      .then((response) => {
        if (response.status === 204) {
          const updatedHouses = houses.filter((h) => h.url !== house.url);
          setHouses(updatedHouses);
          setSelectedHouse({});
          setIsLoading(false);
        }
      })
      .catch((error) => console.log(error));
  };

  return (
    <div>
      {isLoading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <HouseListTable
            houses={houses}
            onSelectHouse={handleSelectHouse}
            onEditHouse={handleEditHouse}
            onDeleteHouse={handleDeleteHouse}
          />
          {Object.keys(selectedHouse).length > 0 && (
            <HouseDetail
              house={selectedHouse}
              isEditing={isEditing}
              onUpdateHouse={handleUpdateHouse}
            />
          )}
        </div>
      )}
    </div>
  );
};

const HouseListTable = ({
  houses,
  onSelectHouse,
  onEditHouse,
  onDeleteHouse,
}) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Name</th>
          <th>Region</th>
          <th>Words</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {houses.map((house) => (
          <tr key={house.url}>
            <td>{house.name}</td>
            <td>{house.region}</td>
            <td>{house.words}</td>
            <td>
              <button onClick={() => onSelectHouse(house)}>View</button>
              <button onClick={() => onEditHouse(house)}>Edit</button>
              <button onClick={() => onDeleteHouse(house)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

const HouseDetail = ({ house, isEditing, onUpdateHouse }) => {
  const [formData, setFormData] = useState({
    name: house.name,
    region: house.region,
    words: house.words,
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div>
      {isEditing ? (
        <form>
          <label>
            Name:
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
            />
          </label>
          <br />
          <label>
            Region:
            <input
              type="text"
              name="region"
              value={formData.region}
              onChange={handleChange}
            />
          </label>
          <br />
          <label>
            Words:
            <input
              type="text"
              name="words"
              value={formData.words}
              onChange={handleChange}
            />
          </label>
          <br />
          <button onClick={() => onUpdateHouse(formData)}>Save</button>
        </form>
      ) : (
        <div>
          <h2>{house.name}</h2>
          <p>Region: {house.region}</p>
          <p>Words: {house.words}</p>
        </div>
      )}
    </div>
  );
};

export default App;
